ShadrackTrades journal update

Files:
- index.html: the corrected journal page.

IMPORTANT:
- Keep your existing supabase-config.js file. It contains your Supabase connection settings and is not included in this ZIP because it was not available in the provided files.
- Back up your current GitHub repository files before replacing anything.
- Extract this ZIP first. Do not upload the ZIP itself expecting GitHub Pages to deploy it.
- In your GitHub repository, replace the existing index.html with this index.html, and leave supabase-config.js and any other required project files in place.
- Commit the change and wait for GitHub Pages to publish.
- The code was syntax-checked but has not been tested against your live Supabase database. Do not delete more trades until cross-device syncing has been tested carefully.
